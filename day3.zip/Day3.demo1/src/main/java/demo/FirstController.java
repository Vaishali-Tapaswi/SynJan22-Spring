package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/first")
public class FirstController{
	@GetMapping()
	@ResponseBody
	public String method1() {
		String str = "Method1 - GET";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}
	@PostMapping
	@ResponseBody
	public String method2() {
		String str = "Method2 - POST";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}
	@PutMapping
	@ResponseBody
	public String method3() {
		String str = "Method3 - PUT";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}
	@DeleteMapping
	@ResponseBody
	public String method4() {
		String str = "Method1 - DELETE";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}
	
}
