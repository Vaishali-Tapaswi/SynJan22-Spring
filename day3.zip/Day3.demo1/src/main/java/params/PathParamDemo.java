package params;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/pp")
public class PathParamDemo {

	@GetMapping(value = "/hello/{nm}")
	public String hello(@PathVariable(name = "nm")String name) {
		System.out.println("PathParamDemo - Hello invoked with " + name);
		return "<h1>Hello, "+name+"</h1>";
	}
	@GetMapping(value = "/add/{num1}/{num2}")
	public String add( @PathVariable(name = "num1") int i ,
			@PathVariable(name = "num2") int j) {
		System.out.println("add invoekd with " + i +", " + j);
		return "<h1>Sum = " + (i+j)+ "</h1>";
	}
}
