package demo;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@ComponentScan(basePackages = "demo")
@Configuration
@EnableTransactionManagement
public class App5 {
	public DataSource ds() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("org.hsqldb.jdbcDriver");
		ds.setUrl("jdbc:hsqldb:hsql://localhost/");
		ds.setUsername("SA");
		ds.setPassword("");
		return ds;
	}

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean bean = new LocalSessionFactoryBean();
		bean.setDataSource(ds());
		bean.setHibernateProperties(hibernateProperties());
		bean.setPackagesToScan("demo");
		return bean;

	}

	@Bean
	public PlatformTransactionManager hibernateTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}

	private final Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "update");
		hibernateProperties.setProperty("hibernate.show_sql", "true");
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");

		return hibernateProperties;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(App5.class);
		System.out.println("-------------Context Loaded-------------------");
	
		
		DeptDAO dao = ctx.getBean(DeptDAO.class);
		
		for (int i = 10;i<100;i+=10) {
			Dept d = new Dept(i, "DNameof"+i, "Hyd");
			if( (i%20)==0)
					d.setLoc("Pnq");
			dao.insert(d);
		}
		dao.delete(20);
		Dept d = new Dept (10,"HR","BLR");
		dao.update(d);
		dao.list().forEach(System.out::println);
	}

}
