package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Dao {
	public Dao() {
		System.out.println("DAO Constructor ");
	}
	@Autowired
	@Qualifier(value = "sqlConnection")
	private Connection con;
	public void insert(){
			getCon().open();
			System.out.println("inserted ");
			getCon().close();
	}
	public Connection getCon() {
		return con;
	}
	public void setCon(Connection con) {
		this.con = con;
	}
}
