package demo;

public interface Connection {
	void open();
	void close();
}
