package demo;

import org.springframework.stereotype.Component;

@Component
public class OracleConnection implements Connection{
	public OracleConnection() {
		System.out.println("OracleConnction Constructor invoked");
	}
	public void open() {
		System.out.println("OracleConnection - Open method invoked ");
	}

	public void close() {
		System.out.println("OracleConnection - Close method invoked ");
	}

}
