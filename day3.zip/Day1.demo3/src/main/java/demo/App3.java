package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages ="demo")
public class App3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(App3.class);
		System.out.println("----------------------------Application Contenxt Loaded-------------------------");
		Dao dao = ctx.getBean(Dao.class);
	/*	Connection con = ctx.getBean(OracleConnection.class);
		dao.setCon(con);
	*/
		dao.insert();
	}
}
