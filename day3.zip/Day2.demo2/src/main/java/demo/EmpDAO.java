package demo;

import java.util.List;

import javax.annotation.PostConstruct;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional()
public class EmpDAO {
		@Autowired
		private SessionFactory sessionFactory;
	    private HibernateTemplate template;
	    public  EmpDAO() { 
		System.out.println("EmpDAO Constructor " + sessionFactory);
		}
	    
	    @PostConstruct
	    public void method1() {
	    	template =  new HibernateTemplate(sessionFactory);
	    }
	    @Transactional(propagation = Propagation.REQUIRES_NEW)
		public void insert(Emp e, Emp e1) {
			System.out.println("Insert in EmpDAO with " + e + ", "+ e1);
			template.persist(e);
			template.persist(e1);
		}
	
}
