package demo;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

public class MyCalcAdvice implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice{

	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		System.out.println("_____________MyCalcAdvice  -afterReturning  " + method.getName() + " with return value " + returnValue);
	}

	public void before(Method method, Object[] args, Object target) throws Throwable {
		System.out.println("_________MyCalcAdvice - before  - " + method.getName() + " with params " + Arrays.toString(args));	
	}
	public void afterThrowing(Method method, Object[] args, Object target, Exception ex) {
		System.out.println("__________MyCalcAdvice - afterThrowing -  " + method.getName() + " with params " + Arrays.toString(args)  +
				" has given error " + ex);
	}

}
