package demo;

import org.springframework.stereotype.Component;

@Component
public class DeptDAO {
public void create() {
	System.out.println("DeptDAO-Create invoked ");
}
public void update() {
	System.out.println("DeptDAO-Update invoked ");
}
public void delete() {
	System.out.println("DeptDAO-Delete invoked ");
}
public void read() {
	System.out.println("DeptDAO-Read invoked ");
}
}
