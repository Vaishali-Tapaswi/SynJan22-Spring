package demo;

public class Calc {
	public int add(int no1, int no2) {
			System.out.println("add invoked with " + no1 + ", "+ no2);
			return no1+no2;
	}
	int divide(String d1, String d2) {
		System.out.println("Divide invoked with " + d1 + ", " + d2);
		int no1 = Integer.parseInt(d1);
		int no2 = Integer.parseInt(d2);
		return no1/no2;
	}
}
