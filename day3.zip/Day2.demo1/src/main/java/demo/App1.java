package demo;

import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "demo")
public class App1 {
	@Bean
	public DeptDAO deptDAO(){
		// return proxy object
		System.out.println("App1 - Bean - deptDAO");
		ProxyFactory factory = new ProxyFactory(new DeptDAO());
		factory.addAdvice(new MyAdvice());
		return (DeptDAO) factory.getProxy();
	}
	@Bean
	public Calc calc(){
		// return proxy object
		System.out.println("App1 - Bean - Calc");
		ProxyFactory factory = new ProxyFactory(new Calc());
		factory.addAdvice(new MyCalcAdvice());
		return (Calc) factory.getProxy();
	}	
public static void main(String[] args) {
	ApplicationContext ctx = new AnnotationConfigApplicationContext(App1.class);
	DeptDAO deptdao = ctx.getBean("deptDAO",DeptDAO.class);
	deptdao.create();
	
	deptdao.read();

	Calc c1 = ctx.getBean("calc", Calc.class);
	c1.add(10, 10);
	c1.divide("10", "5");
//	c1.divide("10", "a5");
	c1.divide("10","0");	

}
}
