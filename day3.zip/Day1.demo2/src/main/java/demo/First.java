package demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "singleton")
@Lazy
public class First {
	public First() {
		System.out.println("First Constructor invoked ");
	}
	public void m1() {
		System.out.println("m1 of First invoked ...");
	}
}
