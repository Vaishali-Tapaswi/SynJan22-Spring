package demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class MyConfiguration {
	@Bean
	@Scope(value = "prototype")
	public Test test() {
		System.out.println("in test method of MyConfiguration");
		return new Test(10);
	}
}
