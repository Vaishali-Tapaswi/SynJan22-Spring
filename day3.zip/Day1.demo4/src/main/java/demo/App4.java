package demo;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = "demo")
public class App4 {
	@Bean
	public DataSource ds () {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("org.hsqldb.jdbcDriver");
		ds.setUrl("jdbc:hsqldb:hsql://localhost/");
		ds.setUsername("SA");
		ds.setPassword("");
		return ds;
	}
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(App4.class);
	DeptDao dao = context.getBean(DeptDao.class);
	dao.insert(10, "HR","Pnq");
}
}
