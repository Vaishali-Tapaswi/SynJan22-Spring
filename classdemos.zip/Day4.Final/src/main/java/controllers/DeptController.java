package controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import daos.DeptDAO;
import entities.Dept;

@RestController
@RequestMapping(value = "/dept")
public class DeptController {
	@Autowired
	private DeptDAO dao;
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public String add(@RequestBody Dept d) {
		System.out.println("Adding " + d);
		dao.save(d);
		return "<h1>Added</h1>";
	}
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Dept> list(){
		 List<Dept> list = dao.findAll();
		System.out.println("List " + list.size());
		return list;
	}
	
}
