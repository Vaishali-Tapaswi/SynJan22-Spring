package demo;

import org.springframework.stereotype.Component;

@Component
public class SqlConnection implements Connection{
	public SqlConnection() {
		System.out.println("SQLConnection Constructor invoked");
	}
	public void open() {
		System.out.println("SQLConnection - Open method invoked ");
	}

	public void close() {
		System.out.println("SQLConnection - Close method invoked ");
	}

}
