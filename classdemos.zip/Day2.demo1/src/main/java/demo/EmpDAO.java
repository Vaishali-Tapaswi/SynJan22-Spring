package demo;

import org.springframework.stereotype.Component;

@Component
public class EmpDAO {
public void create() {
	System.out.println("EmpDAO-Create invoked ");
}
public void update() {
	System.out.println("EmpDAO-Update invoked ");
}
public void delete() {
	System.out.println("EmpDAO-Delete invoked ");
}
public void read() {
	System.out.println("EmpDAO-Read invoked ");
}
}
