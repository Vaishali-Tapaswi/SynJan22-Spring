package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ApplicationContext ctx = new ClassPathXmlApplicationContext("demo.xml");
			System.out.println("------------------------Context Loaded----------------------------");
			Simple s1 = ctx.getBean("sim1",Simple.class);
			s1.m1();
			Simple s2 = ctx.getBean("sim1",Simple.class);
			s2.m1();
			Simple s3 = ctx.getBean("sim1",Simple.class);
			s3.m1();
			
			First f1 = ctx.getBean("first",First.class);
			f1.m1();
			
			First f2 = ctx.getBean("first",First.class);
			f2.m1();
			
			First f3 = ctx.getBean("first",First.class);
			f3.m1();
			
			
	}

}
