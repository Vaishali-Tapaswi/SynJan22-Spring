package demo;

import org.springframework.data.jpa.repository.JpaRepository;

import entities.Dept;

public interface DeptDAO extends JpaRepository<Dept, Integer> {

}
