package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import entities.Dept;

@SpringBootApplication
@EnableJpaRepositories
@EntityScan(value = "entities")
public class JPAApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(JPAApplication.class, args);
		DeptDAO dao = context.getBean("deptDAO",DeptDAO.class);

		for (int i = 10;i<100;i+=10) {
			Dept d = new Dept(i, "DNameof"+i, "Hyd");
			if( (i%20)==0)
					d.setLoc("Pnq");
			dao.save(d);
		}
		Dept d1 = new Dept (20,"..","..");
		dao.delete(d1);
		Dept d = new Dept (10,"HR","BLR");
		dao.save(d);
		dao.findAll().forEach(System.out::println);
		
	}

}
