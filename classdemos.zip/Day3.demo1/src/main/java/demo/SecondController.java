package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
@RestController
@RequestMapping(value="/second")
public class SecondController{
	@GetMapping(value="/s1")
//	@ResponseBody
//	@RequestMapping(value="/s1")
	public String method1() {
		String str = "Second Method1 - GET";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}

	@GetMapping(value="/s2")
//	@ResponseBody
//	@RequestMapping(value="/s2")
	public String method2() {
		String str = "Second Method2 - GET";
		System.out.println(str);
		return "<h1>"+str+"</h1>";
	}
}
