package demo;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/third")
public class ThirdController{
	@GetMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public String method1() {
		String str = "Third Method1 - GET - plain text";
		System.out.println(str);
		return "plain text";
	}

	@GetMapping(produces = MediaType.TEXT_HTML_VALUE)
	public String method2() {
		String str = "Third Method2 - GET - html";
		System.out.println(str);
		return "<h1>HTML Output</h1>";
	}

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public String method3() {
		String str = "Third Method3 - GET - json";
		System.out.println(str);
		return "{\"empno\":10 , \"ename\":\"Vaishali\"}";
	}
	@GetMapping(produces = MediaType.APPLICATION_XML_VALUE)
	public String method4() {
		String str = "Third Method4 - GET - XML";
		System.out.println(str);
		return "\r\n"
				+ "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<note>\r\n"
				+ "  <to>Tove</to>\r\n"
				+ "  <from>Jani</from>\r\n"
				+ "  <heading>Reminder</heading>\r\n"
				+ "  <body>Don't forget me this weekend!</body>\r\n"
				+ "</note>";
	}
		
	
}
