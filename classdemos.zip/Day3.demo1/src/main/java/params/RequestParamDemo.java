package params;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/rp")
public class RequestParamDemo {

	@GetMapping(value = "/hello")
	public String hello(@RequestParam(name = "nm")String name) {
		System.out.println("RequestParam - Hello invoked with " + name);
		return "<h1>Hello, "+name+"</h1>";
	}
	@GetMapping(value = "/add")
	public String add( @RequestParam(name = "num1") int i ,
			@RequestParam(name = "num2") int j) {
		System.out.println("RequestParam add invoked with " + i +", " + j);
		return "<h1>Sum = " + (i+j)+ "</h1>";
	}
}
