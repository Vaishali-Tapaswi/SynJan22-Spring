package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
@RequestMapping(value="/")
public class MyController {
		@GetMapping
		@ResponseBody
		public String method1() {
			String str =
					"<h1><a href='simple' >Simple method </a></h1>"+
					"<h1><a href='admin/m1' >Admin m1 method </a></h1>" +
					"<h1><a href='admin/m2' >Admin m2 method </a></h1>" 	;
					
			System.out.println("in method1");
			return str;
		}
		@GetMapping(value="/simple")
		@ResponseBody
		public String simple() {
			String str = "<h1>Simple Method </h1> <h2><a href='/' >Home</a>";
					
			System.out.println("in simple");
			return str;
		}
		@GetMapping(value="/admin/m1")
		@ResponseBody
		public String m1() {
			String str = "<h1>Admin m1 Method </h1> <h2><a href='/' >Home</a>";
					
			System.out.println("in admin m1");
			return str;
		}
		@GetMapping(value="/admin/m2")
		@ResponseBody
		public String m2() {
			String str = "<h1>Admin m2 Method </h1> <h2><a href='/' >Home</a>";
					
			System.out.println("in admin m1");
			return str;
		}
}
