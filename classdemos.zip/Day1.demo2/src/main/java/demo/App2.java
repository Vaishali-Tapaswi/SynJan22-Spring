package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@ComponentScan(basePackages = "demo")
public class App2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//	ApplicationContext ctx = new ClassPathXmlApplicationContext("demo.xml");
		ApplicationContext ctx = new AnnotationConfigApplicationContext(App2.class);
			System.out.println("------------------------Context Loaded----------------------------");
			Simple s1 = ctx.getBean("sim1",Simple.class);
			s1.m1();
			
			First f1 = ctx.getBean("first",First.class);
			f1.m1();
		
			Test t1 = ctx.getBean("test",Test.class);
			System.out.println("Current t1 = " + t1.getNumber());
			Test t2 = ctx.getBean("test",Test.class);
			System.out.println("Current t2 = " + t2.getNumber());
			
	}
}