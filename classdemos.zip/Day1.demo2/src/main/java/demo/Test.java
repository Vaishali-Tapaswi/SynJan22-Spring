package demo;

import org.springframework.stereotype.Component;

public class Test {
	private int number = 0;
	public Test(int number) {
		// TODO Auto-generated constructor stub
		this.number = number;
	}
	public int getNumber() {
		return number;
	}
	
}
