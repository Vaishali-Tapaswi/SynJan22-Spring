package demo;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
//create table dept (deptno numeric primary key, dname varchar(20),loc varchar(20))
public class DeptDao {
	@Autowired
	private DataSource ds;
	
	public void insert (int deptno, String dname, String loc) {
		String sql ="insert into dept values (" + deptno +",'" + dname + "','"+ loc+ "')";
		System.out.println(sql);
		JdbcTemplate jdbctemplate= new JdbcTemplate(ds);
		jdbctemplate.execute(sql);
				
	}
}
