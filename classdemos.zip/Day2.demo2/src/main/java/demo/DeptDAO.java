package demo;

import java.util.List;

import javax.annotation.PostConstruct;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DeptDAO {
		@Autowired
		private SessionFactory sessionFactory;
	    private HibernateTemplate template;
	    @Autowired
	    private EmpDAO empdao;
	    
	    public  DeptDAO() { 
		System.out.println("DeptDAO Constructor " + sessionFactory);
		}
	    
	    @PostConstruct
	    public void method1() {
	    	template =  new HibernateTemplate(sessionFactory);
	    }
	    @Transactional(propagation = Propagation.REQUIRED)
	    public void saveall(Dept d, Emp e1, Emp e2) {
	    	template.persist(d);
	    	
	    	
	    	empdao.insert(e1, e2);
	    	
	    }
		public void insert(Dept d) {
			System.out.println("Insert in DeptDAO with " + d);
			template.persist(d);
		}
		@Transactional( readOnly = true)
		public List<Dept> list() {
			System.out.println("List in DeptDAO");
			return template.loadAll(Dept.class);
		}
		public void update(Dept d) {
			System.out.println("Update in DeptDAO");
			template.update(d);
		}
		public void delete(int deptno) {
			System.out.println("Delete invoked with " + deptno);
			Dept d= template.get(Dept.class, deptno);
			template.delete(d);
		}
}
